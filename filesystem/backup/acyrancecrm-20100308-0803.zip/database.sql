-- AcyranceCRM MySQL Dump 0.2.1 Intern Alpha
--
-- Database name: acyrancecrm
-- ------------------------------------------------------
-- Server Version: 5.1.48-1
--

--
-- Table structure for table `aufgaben`
--

CREATE TABLE `aufgaben` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `besitzerId` int(11) NOT NULL,
  `_public` tinyint(1) NOT NULL DEFAULT '0',
  `beschreibung` varchar(255) DEFAULT NULL,
  `tag` varchar(255) NOT NULL DEFAULT 'Standard',
  `kundeId` int(11) NOT NULL DEFAULT '-1',
  `start` varchar(255) NOT NULL DEFAULT '1971-02-01 00:00:00',
  `ende` varchar(255) NOT NULL DEFAULT '1971-02-01 00:00:00',
  `created` timestamp NOT NULL DEFAULT '1971-02-01 00:00:00',
  `lastmodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `backup`
--

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(500) NOT NULL,
  `type` tinyint(2) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '1971-02-01 00:00:00',
  `automatic` tinyint(1) NOT NULL DEFAULT '1',
  `benutzerId` int(11) NOT NULL DEFAULT '-1',
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `fileAvailable` tinyint(1) NOT NULL DEFAULT '0',
  `backupSize` bigint(20) NOT NULL DEFAULT '-1',
  `filetype` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;--
-- Dumping data for table `backup`
--

INSERT INTO `backup` (id,path,type,created,automatic,benutzerId,success,fileAvailable,backupSize,filetype) VALUES('1','filesystem/backup/acyrancecrm-20100108-0801.zip','1','2010-07-15 20:01:51','0','1','1','0','-1','0');


--
-- Table structure for table `benutzer`
--

CREATE TABLE `benutzer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL DEFAULT '-1',
  `firmenId` int(11) NOT NULL DEFAULT '-1',
  `level` int(11) NOT NULL DEFAULT '0',
  `unterVermittler` tinyint(1) NOT NULL DEFAULT '0',
  `kennung` varchar(255) DEFAULT NULL,
  `vorname` varchar(255) DEFAULT NULL,
  `nachname` varchar(255) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `strasse` varchar(255) DEFAULT NULL,
  `strasse2` varchar(255) DEFAULT NULL,
  `plz` varchar(255) DEFAULT NULL,
  `ort` varchar(255) DEFAULT NULL,
  `addresseZusatz` varchar(255) DEFAULT NULL,
  `addresseZusatz2` varchar(255) DEFAULT NULL,
  `telefon` varchar(255) DEFAULT NULL,
  `telefon2` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `fax2` varchar(255) DEFAULT NULL,
  `mobil` varchar(255) DEFAULT NULL,
  `mobil2` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email2` varchar(255) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  `homepage2` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `comments` text,
  `custom1` varchar(255) DEFAULT NULL,
  `custom2` varchar(255) DEFAULT NULL,
  `custom3` varchar(255) DEFAULT NULL,
  `custom4` varchar(255) DEFAULT NULL,
  `custom5` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logincount` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kennung` (`kennung`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;--
-- Dumping data for table `benutzer`
--

INSERT INTO `benutzer` (id,parentId,firmenId,level,unterVermittler,kennung,vorname,nachname,firma,strasse,strasse2,plz,ort,addresseZusatz,addresseZusatz2,telefon,telefon2,fax,fax2,mobil,mobil2,email,email2,homepage,homepage2,username,password,comments,custom1,custom2,custom3,custom4,custom5,created,lastlogin,logincount,status) VALUES('1','-1','-1','4','0','11001','Yves','Hoppe','Acyrance Versicherungsmakler','R�thstra�e 28',NULL,'80992','M�nchen',NULL,NULL,'(089) 976 00 414','(089) 322 08 134','(089) 2555 13 1079','(089) 2555 13 1200','0176 24 33 14 82','0177 858 25 74','hoppe@acyrance.de','info@yves-hoppe.de','http://www.acyrance.de','http://www.yves-hoppe.de','yves','12345','Bester Mitarbeiter',NULL,NULL,NULL,NULL,NULL,'2010-07-09 00:00:00','2010-07-15 20:03:48','442','0');


--
-- Table structure for table `kinder`
--

CREATE TABLE `kinder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `kindName` varchar(255) DEFAULT NULL,
  `kindVorname` varchar(255) DEFAULT NULL,
  `kindGeburtsdatum` varchar(255) DEFAULT NULL,
  `kindBeruf` varchar(255) DEFAULT NULL,
  `kindWohnort` varchar(255) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `kunden`
--

CREATE TABLE `kunden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `betreuer` varchar(255) DEFAULT NULL,
  `besitzer` int(11) DEFAULT NULL,
  `kundenNr` varchar(255) NOT NULL,
  `anrede` varchar(255) DEFAULT NULL,
  `titel` varchar(255) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `vorname` varchar(255) DEFAULT NULL,
  `vorname2` varchar(255) DEFAULT NULL,
  `vornameWeitere` varchar(255) DEFAULT NULL,
  `nachname` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `plz` int(11) DEFAULT NULL,
  `stadt` varchar(255) DEFAULT NULL,
  `bundesland` varchar(255) DEFAULT NULL,
  `land` varchar(255) DEFAULT NULL,
  `typ` varchar(255) DEFAULT NULL,
  `familienStand` varchar(255) DEFAULT NULL,
  `ehepartnerId` varchar(255) DEFAULT NULL,
  `telefon` varchar(255) DEFAULT NULL,
  `telefon2` varchar(255) DEFAULT NULL,
  `dienstlichTelefon` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `mobil` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `mail2` varchar(255) DEFAULT NULL,
  `geburtsdatum` varchar(255) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  `beruf` varchar(255) DEFAULT NULL,
  `berufsTyp` varchar(255) DEFAULT NULL,
  `berufsOptionen` varchar(255) DEFAULT NULL,
  `beamter` tinyint(1) DEFAULT NULL,
  `oeffentlicherDienst` tinyint(1) DEFAULT NULL,
  `einkommen` varchar(255) DEFAULT NULL,
  `einkommenNetto` varchar(255) DEFAULT NULL,
  `steuerklasse` varchar(255) DEFAULT NULL,
  `kinderZahl` int(11) DEFAULT NULL,
  `religion` varchar(255) DEFAULT NULL,
  `weiterePersonen` varchar(255) DEFAULT NULL,
  `weiterePersonenInfo` varchar(255) DEFAULT NULL,
  `familienPlanung` varchar(255) DEFAULT NULL,
  `werberKennung` varchar(255) DEFAULT NULL,
  `kontonummer` varchar(255) DEFAULT NULL,
  `bankleitzahl` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `bankeigentuemer` varchar(255) DEFAULT NULL,
  `kontoiban` varchar(255) DEFAULT NULL,
  `kontobic` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `custom1` varchar(255) DEFAULT NULL,
  `custom2` varchar(255) DEFAULT NULL,
  `custom3` varchar(255) DEFAULT NULL,
  `custom4` varchar(255) DEFAULT NULL,
  `custom5` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kundenNr` (`kundenNr`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;--
-- Dumping data for table `kunden`
--

INSERT INTO `kunden` (id,betreuer,besitzer,kundenNr,anrede,titel,firma,vorname,vorname2,vornameWeitere,nachname,street,plz,stadt,bundesland,land,typ,familienStand,ehepartnerId,telefon,telefon2,dienstlichTelefon,fax,mobil,mail,mail2,geburtsdatum,homepage,beruf,berufsTyp,berufsOptionen,beamter,oeffentlicherDienst,einkommen,einkommenNetto,steuerklasse,kinderZahl,religion,weiterePersonen,weiterePersonenInfo,familienPlanung,werberKennung,kontonummer,bankleitzahl,bankname,bankeigentuemer,kontoiban,kontobic,comments,custom1,custom2,custom3,custom4,custom5,created,modified,status) VALUES('1','1','1','11001','Herr',NULL,'Acyrance Versicherungsmakler','Benjamin','Alexander',NULL,'Huber','Libellenstra�e 27','80939','M�nchen','Bayern','Deutschland','privat','ledig',NULL,'089 976 00 414',NULL,NULL,'089 2555 13 1079','0176 2433 14 82','huber@acyrance.de',NULL,'06.01.1972','http://www.acyrance.de','Versicherungsmakler','Dandler',NULL,'0','0',NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2010-07-06 00:00:00','2010-07-07 16:06:40','0');
INSERT INTO `kunden` (id,betreuer,besitzer,kundenNr,anrede,titel,firma,vorname,vorname2,vornameWeitere,nachname,street,plz,stadt,bundesland,land,typ,familienStand,ehepartnerId,telefon,telefon2,dienstlichTelefon,fax,mobil,mail,mail2,geburtsdatum,homepage,beruf,berufsTyp,berufsOptionen,beamter,oeffentlicherDienst,einkommen,einkommenNetto,steuerklasse,kinderZahl,religion,weiterePersonen,weiterePersonenInfo,familienPlanung,werberKennung,kontonummer,bankleitzahl,bankname,bankeigentuemer,kontoiban,kontobic,comments,custom1,custom2,custom3,custom4,custom5,created,modified,status) VALUES('4','Unbekannt','1','11002','Herr','Dr.','','Martin','','','Schulz','Baubergerstr. 52','80992','M�nchen','Bayern','Deutschland',NULL,'Ledig / alleinstehend','','',NULL,NULL,'',NULL,'','','02.07.1970','','','Arbeitnehmer/-in',NULL,'0','0','','','unbekannt','-1','','','',NULL,'','','','','','','','','','','','','','2010-07-13 19:47:38','2010-07-13 19:47:38','0');


--
-- Table structure for table `scheduler`
--

CREATE TABLE `scheduler` (
  `id` int(11) NOT NULL,
  `task` varchar(255) NOT NULL,
  `options` varchar(1000) DEFAULT NULL,
  `repeat` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `termine`
--

CREATE TABLE `termine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `besitzer` int(11) NOT NULL,
  `_public` tinyint(1) NOT NULL DEFAULT '0',
  `beschreibung` varchar(255) DEFAULT NULL,
  `ort` varchar(255) DEFAULT NULL,
  `tag` varchar(255) NOT NULL DEFAULT 'Standard',
  `kundeId` int(11) NOT NULL DEFAULT '-1',
  `teilnehmer` varchar(255) DEFAULT NULL,
  `erinnerung` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ende` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastmodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;--
-- Dumping data for table `termine`
--

INSERT INTO `termine` (id,besitzer,_public,beschreibung,ort,tag,kundeId,teilnehmer,erinnerung,start,ende,created,lastmodified,status) VALUES('1','1','1','Mit Joanna feiern','R�thstra�e 28, M�nchen','Standard','-1','','2010-07-13 13:49:26','2010-07-12 15:00:00','2010-07-12 17:00:00','2010-07-12 00:00:00','2010-07-12 19:25:28','0');
INSERT INTO `termine` (id,besitzer,_public,beschreibung,ort,tag,kundeId,teilnehmer,erinnerung,start,ende,created,lastmodified,status) VALUES('2','1','0','Mit Joanna mehr feiern','R�thstra�e 28, M�nchen','Wichtig','-1',NULL,'2010-07-12 11:42:31','2010-07-12 14:00:00','2010-07-12 16:00:00','2010-07-12 11:42:31','2010-07-12 19:25:34','0');
INSERT INTO `termine` (id,besitzer,_public,beschreibung,ort,tag,kundeId,teilnehmer,erinnerung,start,ende,created,lastmodified,status) VALUES('3','1','0','Joanna erkn�deln','R�thstra�e 28','Wichtig','-1',NULL,'2010-07-13 14:09:16','2010-07-13 13:54:00','2010-07-13 16:54:00','2010-07-13 11:54:53','2010-07-13 13:19:16','0');
INSERT INTO `termine` (id,besitzer,_public,beschreibung,ort,tag,kundeId,teilnehmer,erinnerung,start,ende,created,lastmodified,status) VALUES('4','1','0','Joanna umkn�deln','R�thstra�e 28, M�nchen','Pers�nlich','-1',NULL,'2010-07-13 14:11:12','2010-07-13 14:50:00','2010-07-13 16:50:00','2010-07-13 13:50:59','2010-07-13 14:04:21','0');
